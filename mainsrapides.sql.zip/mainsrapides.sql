-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mer. 23 mars 2022 à 18:39
-- Version du serveur :  10.4.19-MariaDB
-- Version de PHP : 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `mainsrapides`
--
CREATE DATABASE IF NOT EXISTS `mainsrapides` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `mainsrapides`;

-- --------------------------------------------------------

--
-- Structure de la table `addlog_table`
--

CREATE TABLE `addlog_table` (
  `IDEvenement` int(10) NOT NULL,
  `CodeEvenement` varchar(6) NOT NULL DEFAULT '',
  `MessageEvenement` varchar(500) NOT NULL DEFAULT '',
  `DateEvenement` varchar(10) NOT NULL DEFAULT '',
  `HeureEvenement` varchar(10) NOT NULL DEFAULT '',
  `PseudoUtilisateur` varchar(50) NOT NULL DEFAULT '',
  `AdresseIP` varchar(25) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `addlog_table`
--

INSERT INTO `addlog_table` (`IDEvenement`, `CodeEvenement`, `MessageEvenement`, `DateEvenement`, `HeureEvenement`, `PseudoUtilisateur`, `AdresseIP`) VALUES
(1, 'Err-02', 'Saisie d’email ou Pseudo invalide lors de la connexion', '2022-03-04', '16:01:04', '-', '::1'),
(2, 'Err-02', 'Saisie d’email ou Pseudo invalide lors de la connexion', '2022-03-04', '16:01:20', '-', '::1'),
(3, 'Err-02', 'Saisie d’email ou Pseudo invalide lors de la connexion', '2022-03-04', '16:02:18', '-', '::1'),
(4, 'Err-02', 'Saisie d’email ou Pseudo invalide lors de la connexion', '2022-03-04', '16:04:06', '-', '::1'),
(5, 'Err-02', 'Saisie d’email ou Pseudo invalide lors de la connexion', '2022-03-04', '16:05:08', '-', '::1'),
(6, 'Err-03', 'Tentative de connexion au compte désactivé de  : Dever Luap', '2022-03-04', '16:55:49', '-', '::1'),
(7, 'Log-01', 'Connexion à l’application réussie', '2022-03-04', '16:57:46', 'Dever Luap - Administrateur', '::1'),
(8, 'Log-01', 'Connexion à l’application réussie', '2022-03-04', '16:58:56', 'Smith Paul - Administrateur', '::1'),
(9, 'Log-01', 'Connexion à l’application réussie', '2022-03-06', '20:55:56', 'Smith Paul - Administrateur', '127.0.0.1'),
(10, 'Log-01', 'Connexion à l’application réussie', '2022-03-06', '21:10:15', 'Smith Paul - Administrateur', '127.0.0.1'),
(11, 'Log-01', 'Connexion à l’application réussie', '2022-03-06', '21:12:47', 'Smith Paul - Administrateur', '127.0.0.1'),
(12, 'Log-02', 'Déconnexion réussie', '2022-03-06', '21:29:12', 'Smith Paul - Client', '127.0.0.1'),
(13, 'Log-01', 'Connexion à l’application réussie', '2022-03-06', '21:36:55', 'Smith Paul - Client', '127.0.0.1'),
(14, 'Log-01', 'Connexion à l’application réussie', '2022-03-07', '07:36:44', 'Smith Paul - Client', '::1'),
(15, 'Log-02', 'Déconnexion réussie', '2022-03-09', '08:31:01', 'Smith Paul - Client', '::1'),
(16, 'Log-02', 'Déconnexion réussie', '2022-03-09', '10:35:01', 'Smith Paul - Client', '::1'),
(17, 'Log-02', 'Déconnexion réussie', '2022-03-09', '15:07:35', 'Smith Paul - Client', '::1'),
(18, 'Log-02', 'Déconnexion réussie', '2022-03-09', '15:25:43', 'Smith Paul - Client', '::1'),
(19, 'Log-02', 'Déconnexion réussie', '2022-03-09', '15:26:58', 'Divane Cheslay - Client', '::1'),
(20, 'Log-02', 'Déconnexion réussie', '2022-03-12', '22:51:34', 'Smith Paul - Client', '127.0.0.1'),
(21, 'Log-02', 'Déconnexion réussie', '2022-03-12', '23:14:22', 'Divane Cheslay - Client', '127.0.0.1'),
(22, 'Log-02', 'Déconnexion réussie', '2022-03-13', '21:13:59', 'Smith Paul - Client', '127.0.0.1'),
(23, 'Enr-20', 'Enregistrement d\'une nouvelle classe : User', '2022-03-13', '21:15:02', 'Dev User - Client', '127.0.0.1'),
(24, 'Enr-20', 'Enregistrement d\'une nouvelle classe : User', '2022-03-13', '21:15:10', 'Dev User - Client', '127.0.0.1'),
(25, 'Enr-20', 'Enregistrement d\'une nouvelle classe : User', '2022-03-13', '21:17:55', 'Dev User - Client', '127.0.0.1'),
(26, 'Enr-20', 'Enregistrement d\'une nouvelle classe : User', '2022-03-13', '21:19:26', 'Dev User - Client', '127.0.0.1'),
(27, 'Log-01', 'Connexion à l’application réussie', '2022-03-13', '21:19:38', 'Dev User - Client', '127.0.0.1'),
(28, 'Log-01', 'Connexion à l’application réussie', '2022-03-13', '21:22:39', 'Dev User - Client', '127.0.0.1'),
(29, 'Log-01', 'Connexion à l’application réussie', '2022-03-13', '21:25:23', 'Dev User - Client', '127.0.0.1'),
(30, 'Log-02', 'Déconnexion réussie', '2022-03-13', '21:25:27', 'Dev User - Client', '127.0.0.1'),
(31, 'Enr-20', 'Enregistrement d\'une nouvelle classe : User', '2022-03-13', '21:26:22', 'Dev User - Client', '127.0.0.1'),
(32, 'Log-01', 'Connexion à l’application réussie', '2022-03-13', '21:26:26', 'Dev User - Client', '127.0.0.1'),
(33, 'Log-02', 'Déconnexion réussie', '2022-03-13', '21:54:44', 'Dev User - Client', '127.0.0.1'),
(34, 'Log-01', 'Connexion à l’application réussie', '2022-03-13', '21:54:48', 'Smith Paul - Client', '127.0.0.1'),
(35, 'Log-02', 'Déconnexion réussie', '2022-03-13', '22:53:31', 'Smith Paul - Client', '127.0.0.1'),
(36, 'Log-01', 'Connexion à l’application réussie', '2022-03-13', '22:54:34', 'Smith Paul - Client', '127.0.0.1'),
(37, 'Log-01', 'Connexion à l’application réussie', '2022-03-14', '05:11:23', 'Smith Paul - Client', '127.0.0.1'),
(38, 'Log-01', 'Connexion à l’application réussie', '2022-03-14', '12:47:27', 'Smith Paul - Client', '::1'),
(39, 'Log-02', 'Déconnexion réussie', '2022-03-14', '17:44:18', 'Smith Paul - Client', '::1'),
(40, 'Log-01', 'Connexion à l’application réussie', '2022-03-14', '17:45:21', 'Smith Paul - Client', '::1'),
(41, 'Log-02', 'Déconnexion réussie', '2022-03-15', '08:59:56', 'Smith Paul - Client', '::1'),
(42, 'Log-01', 'Connexion à l’application réussie', '2022-03-15', '08:59:58', 'Dever Paul - Client', '::1'),
(43, 'Log-02', 'Déconnexion réussie', '2022-03-15', '13:46:42', 'Dever Paul - Client', '::1'),
(44, 'Log-01', 'Connexion à l’application réussie', '2022-03-15', '15:45:49', 'Dever Paul - Client', '::1'),
(45, 'Log-02', 'Déconnexion réussie', '2022-03-15', '17:02:20', 'Dever Paul - Client', '::1'),
(46, 'Log-01', 'Connexion à l’application réussie', '2022-03-15', '17:02:23', 'Paul Smith - Client', '::1'),
(47, 'Log-02', 'Déconnexion réussie', '2022-03-16', '10:18:33', 'Paul Smith - Client', '::1'),
(48, 'Log-01', 'Connexion à l’application réussie', '2022-03-16', '10:18:35', 'Paul Smith - Client', '::1'),
(49, 'Log-02', 'Déconnexion réussie', '2022-03-16', '13:58:22', 'Paul Smith - Client', '::1'),
(50, 'Log-01', 'Connexion à l’application réussie', '2022-03-16', '14:18:44', 'Paul Smith - Client', '::1'),
(51, 'Log-02', 'Déconnexion réussie', '2022-03-16', '14:22:51', 'Paul Smith - Client', '::1'),
(52, 'Log-01', 'Connexion à l’application réussie', '2022-03-16', '15:10:23', 'Paul Smith - Client', '::1'),
(53, 'Log-02', 'Déconnexion réussie', '2022-03-16', '16:29:48', 'Paul Smith - Client', '::1'),
(54, 'Log-01', 'Connexion à l’application réussie', '2022-03-16', '16:49:30', 'Paul Smith - Client', '::1'),
(55, 'Log-02', 'Déconnexion réussie', '2022-03-17', '04:44:10', 'Paul Smith - Client', '::1'),
(56, 'Log-01', 'Connexion à l’application réussie', '2022-03-17', '04:44:12', 'Paul Smith - Client', '::1'),
(57, 'Log-02', 'Déconnexion réussie', '2022-03-17', '07:51:04', 'Paul Smith - Client', '::1'),
(58, 'Log-01', 'Connexion à l’application réussie', '2022-03-17', '07:52:22', 'Paul Smith - Client', '::1'),
(59, 'Log-02', 'Déconnexion réussie', '2022-03-17', '08:35:10', 'Paul Smith - Client', '::1'),
(60, 'Log-01', 'Connexion à l’application réussie', '2022-03-17', '08:35:44', 'Paul Smith - Client', '::1'),
(61, 'Log-02', 'Déconnexion réussie', '2022-03-17', '09:50:59', 'Paul Smith - Client', '::1'),
(62, 'Log-02', 'Déconnexion réussie', '2022-03-17', '10:19:27', 'Paul Smith - Client', '::1'),
(63, 'Log-02', 'Déconnexion réussie', '2022-03-17', '13:09:35', 'Paul Smith - Client', '::1'),
(64, 'Log-02', 'Déconnexion réussie', '2022-03-21', '15:10:22', 'Paul Smith - Client', '127.0.0.1'),
(65, 'Log-02', 'Déconnexion réussie', '2022-03-21', '16:41:53', 'Divane Cheslay - Client', '127.0.0.1'),
(66, 'Log-02', 'Déconnexion réussie', '2022-03-21', '16:43:06', 'Paul Smith - Client', '127.0.0.1'),
(67, 'Log-02', 'Déconnexion réussie', '2022-03-22', '13:59:43', 'Paul Smith - Client', '127.0.0.1'),
(68, 'Log-02', 'Déconnexion réussie', '2022-03-22', '16:58:14', 'Paul Smith - Client', '127.0.0.1'),
(69, 'Log-02', 'Déconnexion réussie', '2022-03-23', '05:35:37', 'Paul Smith - Client', '::1'),
(70, 'Log-02', 'Déconnexion réussie', '2022-03-23', '05:38:19', 'Divane Cheslay - Client', '::1'),
(71, 'Log-02', 'Déconnexion réussie', '2022-03-23', '09:57:42', 'Paul Smith - Client', '::1'),
(72, 'Log-02', 'Déconnexion réussie', '2022-03-23', '14:56:31', 'Paul Smith - Client', '::1'),
(73, 'Log-02', 'Déconnexion réussie', '2022-03-23', '15:34:46', 'Paul Smith - Client', '::1'),
(74, 'Log-02', 'Déconnexion réussie', '2022-03-23', '15:41:37', 'Paul Smith - Client', '::1'),
(75, 'Log-02', 'Déconnexion réussie', '2022-03-23', '17:30:01', 'Paul Smith - Client', '::1');

-- --------------------------------------------------------

--
-- Structure de la table `adresses`
--

CREATE TABLE `adresses` (
  `id` int(10) UNSIGNED NOT NULL,
  `label` varchar(255) NOT NULL,
  `status` enum('enable','disable','deleted') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `adresses`
--

INSERT INTO `adresses` (`id`, `label`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Cotonou', 'enable', '2022-03-08 15:15:12', '2022-03-08 15:15:12', '2022-03-08 15:14:43'),
(2, 'Porto-Novo', 'enable', '2022-03-08 15:15:12', '2022-03-08 15:15:12', '2022-03-08 15:14:43'),
(3, 'Ouidah', 'enable', '2022-03-08 15:15:37', '2022-03-08 15:15:37', '2022-03-08 15:15:15'),
(4, 'Abomey-Calavi', 'enable', '2022-03-08 15:15:37', '2022-03-08 15:15:37', '2022-03-08 15:15:15'),
(5, 'Bohicon', 'enable', '2022-03-08 15:15:56', '2022-03-08 15:15:56', '2022-03-08 15:15:40'),
(6, 'Parakou', 'enable', '2022-03-08 15:15:56', '2022-03-08 15:15:56', '2022-03-08 15:15:40');

-- --------------------------------------------------------

--
-- Structure de la table `annonces`
--

CREATE TABLE `annonces` (
  `id` int(10) UNSIGNED NOT NULL,
  `titre` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `creneau` varchar(255) DEFAULT NULL,
  `date_fixed` date DEFAULT NULL,
  `expired_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `photo1` varchar(255) DEFAULT '/assets/img/annonce1.png',
  `photo2` varchar(255) DEFAULT NULL,
  `photo3` varchar(255) DEFAULT NULL,
  `place` varchar(255) NOT NULL,
  `prix_min` int(11) NOT NULL,
  `prix_max` int(11) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `travail_id` int(10) UNSIGNED NOT NULL,
  `status` enum('enable','on_way','finished','disable','deleted') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `annonces`
--

INSERT INTO `annonces` (`id`, `titre`, `description`, `creneau`, `date_fixed`, `expired_at`, `photo1`, `photo2`, `photo3`, `place`, `prix_min`, `prix_max`, `telephone`, `user_id`, `travail_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(5, 'Installation et réparation lave vaisselle', 'Bonjour,\r\nJe souhaite réparer mon ancien lave vaisselle et l’installer. Et si cela n’est pas possible je voudrai en installer un nouveau. Les deux lave vaisselle sont déjà dans l’appartement. Merci!', NULL, '2022-03-21', '0000-00-00 00:00:00', '/assets/img/uploads/annonce/annonce9385270b9b097d413a124e5c56896bf9.jpg', '', '', 'Cotonou', 8, 16, '90667333', 4, 2, 'enable', '2022-03-08 11:37:51', '2022-03-08 11:37:51', NULL),
(6, 'Fixer ma TV', 'Description de Fixer ma TV', NULL, '2022-03-12', '0000-00-00 00:00:00', '/assets/img/uploads/annonce/annonced400933d5122613686d2a7f818a366dd.png', '/assets/img/uploads/annonce/annonce85bb5ce8383e071bffd7acd7d5452c5d.jpg', '', 'Porto-Novo', 9, 24, '90667333', 4, 1, 'enable', '2022-03-08 12:34:45', '2022-03-08 12:34:45', NULL),
(11, 'Fixer mon ecran', 'Description de Fixer mon ecran.\r\ndcjnjcnchjhjendce', NULL, '2022-03-21', '0000-00-00 00:00:00', '/assets/img/uploads/annonce/annonce053f2f4e5ccf1056ba25e278dd1888bd.png', '', '', 'Porto-Novo', 17, 28, '90667333', 4, 2, 'enable', '2022-03-13 00:21:17', '2022-03-13 00:21:17', NULL),
(12, 'Fixer mon miroir', 'Je recherche un jobber pour fixer mon miroir neuf avec un budget entre 18 et 26$', NULL, '2022-03-10', '0000-00-00 00:00:00', '/assets/img/uploads/annonce/miroir.jpg', NULL, NULL, 'Parakou', 18, 26, '22954258966', 10, 4, 'enable', '2022-03-17 09:18:37', '2022-03-17 09:18:37', '2022-03-17 09:15:04'),
(13, 'Recherche couturière caftan sur mesure', 'Je recherche une couturière un caftan sur mesure neuf avec un budget entre 20 et 30$', NULL, '2022-03-10', '0000-00-00 00:00:00', '/assets/img/uploads/annonce/mesure.jpg', NULL, NULL, 'Abomey-Calavi', 18, 26, '22954258966', 10, 4, 'enable', '2022-03-17 09:21:28', '2022-03-17 09:21:28', '2022-03-17 09:15:04'),
(14, 'Tapisserie', 'Bonjour,\r\nJe recherche une personne sérieuse afin de tapisser dans mon nouveau appartement.\r\nSur la commune, de wervicq-sud.', NULL, '2022-03-10', '0000-00-00 00:00:00', '/assets/img/uploads/annonce/tapis.jpg', '/assets/img/uploads/annonce/annonced400933d5122613686d2a7f818a366er.jpg', NULL, 'Cotonou', 45, 58, '22921586322', 3, 3, 'enable', '2022-03-17 09:31:55', '2022-03-17 09:31:55', '2022-03-17 09:22:31'),
(15, 'Purge ou détartrage radiateurs', 'Mes radiateurs sont froids alors que ma chaudiere fonctionne. Purge à faire voire detartrage', NULL, '2022-03-10', '0000-00-00 00:00:00', '/assets/img/uploads/annonce/annonced400933d5122613686d2a7f81h43756er.png', NULL, NULL, 'Ouidah', 60, 65, '22958342255', 3, 2, 'enable', '2022-03-17 09:56:03', '2022-03-17 09:56:03', '2022-03-17 09:54:34'),
(16, 'Création chatière', 'Mise en place d’une chatière dans un volet en bois', NULL, '2022-03-03', '0000-00-00 00:00:00', '/assets/img/uploads/annonce/annonce72acded3acd45e4c8b6ed680854b8ab1.jpg', '/assets/img/annonce1.png', NULL, 'Cotonou', 30, 40, '22952586685', 15, 1, 'enable', '2022-03-17 10:31:49', '2022-03-17 10:31:49', '2022-03-17 10:29:51'),
(17, 'Retirer porte à charnières remplacer porte sur rails', 'Retirer porte à charnières remplacer porte sur rails', NULL, '2022-03-17', '0000-00-00 00:00:00', '/assets/img/uploads/annonce/annonce72dfded3acd45e4c8b6ed680854b8ab1.jpg', '/assets/img/annonce1.png', NULL, 'Porto-Novo', 100, 250, '22963856621', 4, 3, 'enable', '2022-03-17 10:35:46', '2022-03-17 10:35:46', '2022-03-17 10:33:39'),
(18, 'Work 1', 'ndnducdeudeuieduedediejdue', NULL, '2022-03-25', '2022-03-25 00:00:00', '/assets/img/uploads/annonce/annonce1ac1bb822893fe03634a13e85b318af8.jpg', '', '', 'Ouidah', 25, 52, '22952148596', 16, 5, 'on_way', '2022-03-23 16:19:03', '2022-03-23 16:19:03', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `badge_identity`
--

CREATE TABLE `badge_identity` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` enum('carte','passeport') NOT NULL,
  `recto` varchar(255) NOT NULL,
  `verso` varchar(255) DEFAULT NULL,
  `country` varchar(255) NOT NULL,
  `date_expired` date NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `status` enum('enable','on_way','finished','disable','deleted') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `badge_identity`
--

INSERT INTO `badge_identity` (`id`, `type`, `recto`, `verso`, `country`, `date_expired`, `user_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'carte', '/assets/img/uploads/user/badge/carte_identitycb02e538041b10a19dc68f281afb7b78.png', '/assets/img/uploads/user/badge/carte_identity414f6e3d79291da54da0b27675b62971.png', 'Benin', '2022-03-09', 4, 'enable', '2022-03-15 11:41:08', '2022-03-15 11:41:08', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `biling_info`
--

CREATE TABLE `biling_info` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `entreprise_name` varchar(255) NOT NULL,
  `email_bill` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `adress1` varchar(255) NOT NULL,
  `adress2` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `code_postal` varchar(255) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `status` enum('enable','on_way','finished','disable','deleted') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `biling_info`
--

INSERT INTO `biling_info` (`id`, `first_name`, `last_name`, `entreprise_name`, `email_bill`, `city`, `adress1`, `adress2`, `country`, `code_postal`, `user_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Ron', 'Doe', 'Aaaz Tech', 'entreprise@gmail.com', 'Cotonou', 'TL-0142', 'TL-0578', 'Benin', '257856', 4, 'enable', '2022-03-14 08:30:04', '2022-03-14 08:30:04', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `book_photo`
--

CREATE TABLE `book_photo` (
  `id` int(10) UNSIGNED NOT NULL,
  `photo` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `categorie_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `status` enum('enable','on_way','finished','disable','deleted') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `book_photo`
--

INSERT INTO `book_photo` (`id`, `photo`, `description`, `categorie_id`, `user_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(7, '/assets/img/uploads/user/book/bookf05c9e85bb7dedb65045b4c116949bc1.png', 'Description of this photo....', 1, 4, 'enable', '2022-03-14 13:48:50', '2022-03-14 13:48:50', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT '/assets/img/annonce2.png',
  `label` varchar(255) NOT NULL,
  `status` enum('enable','disable','deleted') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id`, `photo`, `label`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '/assets/img/annonce2.png', 'Jardin et extérieur\r\n', 'enable', '2022-03-07 12:19:17', '2022-03-07 12:19:17', '2022-03-07 12:19:07'),
(2, '/assets/img/annonce2.png', 'Petits travaux', 'enable', '2022-03-08 08:23:31', '2022-03-08 08:23:31', '2022-03-08 08:23:21'),
(6, '/assets/img/uploads/categorie/categoriecc5fdaf02aae4359c4cb54b3fd7532d1.jpg', 'Test Category', 'enable', '2022-03-20 23:15:15', '2022-03-20 23:21:00', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `from_user_id` int(10) UNSIGNED NOT NULL,
  `to_user_id` int(10) UNSIGNED NOT NULL,
  `message` text NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('enable','disable','deleted') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `message`, `seen`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 10, 4, 'Hi.\r\nIt\' just a test.', 1, 'enable', '2022-03-22 11:13:45', '2022-03-22 11:13:45', NULL),
(2, 4, 10, 'Ok Divane, received', 1, 'enable', '2022-03-22 14:01:59', '2022-03-22 14:01:59', NULL),
(21, 10, 4, 'Are you OK ?', 1, 'enable', '2022-03-22 15:38:35', '2022-03-22 15:38:35', NULL),
(22, 4, 10, 'Yes and you', 1, 'enable', '2022-03-22 15:38:40', '2022-03-22 15:38:40', NULL),
(23, 10, 4, 'I\'m good', 1, 'enable', '2022-03-22 15:41:00', '2022-03-22 15:41:00', NULL),
(24, 4, 10, 'OK', 1, 'enable', '2022-03-22 15:41:11', '2022-03-22 15:41:11', NULL),
(25, 10, 4, 'What are you doing ?', 1, 'enable', '2022-03-22 15:41:52', '2022-03-22 15:41:52', NULL),
(26, 4, 10, 'I\'m working', 1, 'enable', '2022-03-22 16:33:11', '2022-03-22 16:33:11', NULL),
(27, 10, 4, 'Okay', 1, 'enable', '2022-03-22 17:02:25', '2022-03-22 17:02:25', NULL),
(28, 4, 10, 'And you ??', 1, 'enable', '2022-03-22 17:09:09', '2022-03-22 17:09:09', NULL),
(29, 10, 4, 'Nothing', 1, 'enable', '2022-03-22 17:09:40', '2022-03-22 17:09:40', NULL),
(30, 10, 4, 'I\'m just cooking', 1, 'enable', '2022-03-22 17:12:29', '2022-03-22 17:12:29', NULL),
(31, 10, 4, 'Bla bla', 1, 'enable', '2022-03-22 17:12:46', '2022-03-22 17:12:46', NULL),
(32, 4, 10, 'Good morning Paul', 1, 'enable', '2022-03-23 06:35:33', '2022-03-23 06:35:33', NULL),
(33, 10, 4, 'Hi Paul', 1, 'enable', '2022-03-23 06:38:12', '2022-03-23 06:38:12', NULL),
(37, 16, 4, 'Hi Paul !!', 1, 'enable', '2022-03-23 17:30:18', '2022-03-23 17:30:18', NULL),
(38, 4, 16, 'Hi Luap, how are you ?', 1, 'enable', '2022-03-23 17:34:11', '2022-03-23 17:34:11', NULL),
(39, 16, 4, 'Fine and you ?', 1, 'enable', '2022-03-23 17:34:28', '2022-03-23 17:34:28', NULL),
(40, 16, 4, '??', 1, 'enable', '2022-03-23 18:32:10', '2022-03-23 18:32:10', NULL),
(41, 4, 16, 'osnjjds', 1, 'enable', '2022-03-23 18:32:20', '2022-03-23 18:32:20', NULL),
(42, 16, 4, 'ddeded', 1, 'enable', '2022-03-23 18:32:31', '2022-03-23 18:32:31', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `to_user_id` int(10) UNSIGNED NOT NULL,
  `message` varchar(255) NOT NULL,
  `target_link` varchar(255) NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('enable','on_way','finished','disable','deleted') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `notifications`
--

INSERT INTO `notifications` (`id`, `title`, `to_user_id`, `message`, `target_link`, `seen`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, 'Luap Admin', 4, 'a fait une offre pour l\'annonce Fixer ma TV', 'http://localhost:8081/mainsrapides/annonce_single.php?id=6', 0, 'enable', '2022-03-23 17:04:34', '2022-03-23 17:04:34', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `offre_annonce`
--

CREATE TABLE `offre_annonce` (
  `id` int(10) UNSIGNED NOT NULL,
  `annonce_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `prix` int(11) NOT NULL,
  `accepted` tinyint(1) DEFAULT 0,
  `status` enum('enable','disable','deleted') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `offre_annonce`
--

INSERT INTO `offre_annonce` (`id`, `annonce_id`, `user_id`, `prix`, `accepted`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(14, 5, 4, 15, 0, 'enable', '2022-03-09 13:19:35', '2022-03-09 13:19:35', NULL),
(17, 18, 4, 33, 1, 'enable', '2022-03-23 16:30:13', '2022-03-23 16:30:13', NULL),
(20, 6, 16, 13, 0, 'enable', '2022-03-23 17:04:34', '2022-03-23 17:04:34', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `paiements`
--

CREATE TABLE `paiements` (
  `id` int(10) UNSIGNED NOT NULL,
  `somme` int(10) UNSIGNED NOT NULL,
  `commission` int(11) NOT NULL,
  `offre_id` int(10) UNSIGNED NOT NULL,
  `annonce_id` int(10) UNSIGNED NOT NULL,
  `user_client` int(10) UNSIGNED NOT NULL,
  `user_jobber` int(10) UNSIGNED NOT NULL,
  `status` enum('enable','disable','deleted','en_cours','paye','terminer') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `paiements`
--

INSERT INTO `paiements` (`id`, `somme`, `commission`, `offre_id`, `annonce_id`, `user_client`, `user_jobber`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 33, 7, 17, 18, 16, 4, 'paye', '2022-03-23 16:39:55', '2022-03-23 16:39:55', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `label` varchar(255) NOT NULL,
  `status` enum('enable','disable','deleted') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `roles`
--

INSERT INTO `roles` (`id`, `label`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'client', 'enable', '2022-03-04 18:52:58', '2022-03-04 18:52:58', NULL),
(2, 'jobber', 'enable', '2022-03-04 18:53:10', '2022-03-04 18:53:10', NULL),
(3, 'lecteur', 'enable', '2022-03-20 12:11:34', '2022-03-20 12:11:34', '2022-03-20 12:10:40'),
(4, 'editeur', 'enable', '2022-03-20 12:11:34', '2022-03-20 12:11:34', '2022-03-20 12:10:40'),
(5, 'administrateur', 'enable', '2022-03-20 13:39:33', '2022-03-20 13:39:33', '2022-03-20 13:39:22');

-- --------------------------------------------------------

--
-- Structure de la table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT '/assets/img/annonce2.png',
  `label` varchar(255) NOT NULL,
  `categorie_id` int(10) UNSIGNED NOT NULL,
  `status` enum('enable','disable','deleted') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `subcategories`
--

INSERT INTO `subcategories` (`id`, `photo`, `label`, `categorie_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '/assets/img/annonce2.png', 'Entretien jardin', 1, 'enable', '2022-03-07 15:39:20', '2022-03-07 15:39:20', '2022-03-07 15:39:03'),
(2, '/assets/img/annonce2.png', 'Accroche murale', 2, 'enable', '2022-03-08 08:23:55', '2022-03-08 08:23:55', '2022-03-08 08:23:38'),
(3, '/assets/img/annonce2.png', 'Aménagement jardin', 1, 'enable', '2022-03-08 10:13:01', '2022-03-08 10:13:01', '2022-03-08 10:12:44'),
(4, '/assets/img/uploads/subcategorie/subcategorie21b23a2d7c69c1ae44ca2808d366ee0c.jpg', 'Test SubCategorie', 6, 'enable', '2022-03-20 23:43:45', '2022-03-20 23:46:00', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `travaux`
--

CREATE TABLE `travaux` (
  `id` int(10) UNSIGNED NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT '/assets/img/annonce2.png',
  `label` varchar(255) NOT NULL,
  `subcategorie_id` int(10) UNSIGNED NOT NULL,
  `status` enum('enable','disable','deleted') NOT NULL DEFAULT 'enable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `travaux`
--

INSERT INTO `travaux` (`id`, `photo`, `label`, `subcategorie_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '/assets/img/annonce2.png', 'Tonte de pelouse', 1, 'enable', '2022-03-07 16:04:09', '2022-03-07 16:04:09', NULL),
(2, '/assets/img/annonce2.png', 'Taille de haie', 1, 'enable', '2022-03-07 16:04:09', '2022-03-07 16:04:09', NULL),
(3, '/assets/img/annonce2.png', 'Engazonnement', 2, 'enable', '2022-03-08 08:24:19', '2022-03-08 08:24:19', '2022-03-08 08:24:02'),
(4, '/assets/img/annonce2.png', 'Fixation miroir', 3, 'enable', '2022-03-08 10:14:36', '2022-03-08 10:14:36', '2022-03-08 10:14:07'),
(5, '/assets/img/uploads/travail/travail53dc8ac0a1dc51c17cebc5daa76bd0b6.png', 'Test Work', 4, 'enable', '2022-03-21 08:45:32', '2022-03-21 08:50:00', '2022-03-21 08:50:00');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `mdp` varchar(255) NOT NULL,
  `skills` text NOT NULL DEFAULT '\'\'',
  `photo` varchar(255) DEFAULT '/assets/img/usr_avatar.png',
  `code_postal` varchar(255) NOT NULL DEFAULT '',
  `adresse` varchar(255) DEFAULT NULL,
  `ville` varchar(255) DEFAULT NULL,
  `sexe` varchar(255) DEFAULT NULL,
  `date_naissance` datetime DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `avis` text NOT NULL DEFAULT 'Aucun avis',
  `token` varchar(255) DEFAULT NULL,
  `email_confirmed_at` datetime DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `num_confirmed_at` datetime DEFAULT NULL,
  `news` tinyint(1) NOT NULL DEFAULT 1,
  `plans` tinyint(1) NOT NULL DEFAULT 0,
  `alertes` enum('chaque','jour','jamais') NOT NULL DEFAULT 'chaque',
  `role_id` int(10) UNSIGNED NOT NULL,
  `status` enum('enable','disable','deleted') NOT NULL DEFAULT 'disable',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `email`, `prenom`, `nom`, `telephone`, `mdp`, `skills`, `photo`, `code_postal`, `adresse`, `ville`, `sexe`, `date_naissance`, `bio`, `avis`, `token`, `email_confirmed_at`, `code`, `num_confirmed_at`, `news`, `plans`, `alertes`, `role_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 'pzannou@gmail.com', 'Dever', 'Luap', '', '$2y$10$kIpbCdvtwnjUw9A2nL9pw.nvKHvwfmm8Vur000uwj5KNIR7ReH.kS', '[]', '/assets/img/usr_avatar.png', '257856', NULL, NULL, NULL, NULL, NULL, 'Jobber ponctuel et motivé, il a été disponible ce dimanche matin pour poser ma pelouse synthétique et j’en suis ravie.', NULL, NULL, NULL, NULL, 1, 0, 'chaque', 1, 'enable', '2022-03-04 18:55:35', '2022-03-04 18:55:35', NULL),
(4, 'pzannou511@gmail.com', 'Paul', 'Smith', '22990667333', '$2y$10$kIpbCdvtwnjUw9A2nL9pw.nvKHvwfmm8Vur000uwj5KNIR7ReH.kS', '1', '/assets/img/uploads/user/user166eec64857bdb26714e37bd859b9932.jpg', '257856', 'TL-0142', NULL, 'Masculin', NULL, 'My name\'s ...., my description', 'Super travail réalisé par Thybault. La haie a été parfaitement taillée, les déchets évacués. Merci', 'c2f911c37f7a63ea45d537e08acecd59bb9d9950f3c3f38397606124ec417640', '2022-03-14 18:46:00', NULL, '2022-03-15 10:11:00', 1, 1, 'jamais', 1, 'enable', '2022-03-04 18:58:42', '2022-03-04 18:58:42', NULL),
(10, 'divanecheslay@gmail.com', 'Divane', 'Cheslay', NULL, '$2y$10$Xat6e8idm5efLh/17m5HoexLMZK7lP.T3Rn3FhF.d2AcaeIADFQ/K', '[]', '/assets/img/usr_avatar.png', '257856', NULL, NULL, NULL, NULL, NULL, 'Très contente de la prestation, Jorge est de très bon conseil et compétent. Je suis ravie de l\'aménagement.', NULL, NULL, NULL, NULL, 1, 0, 'chaque', 1, 'enable', '2022-03-09 16:18:02', '2022-03-09 16:18:02', NULL),
(15, 'devuser@gmail.com', 'Dev', 'User', NULL, '$2y$10$H23M6wcv6g4Wwv/M0g/z/uBJVJo5BCFARIovqCULl2JRr2ndl52Um', '[]', '/assets/img/usr_avatar.png', '25712', NULL, NULL, NULL, NULL, NULL, 'Super travail réalisé par Thybault. La haie a été parfaitement taillée, les déchets évacués. Merci', NULL, NULL, NULL, NULL, 1, 0, 'chaque', 1, 'enable', '2022-03-13 22:26:21', '2022-03-13 22:26:21', NULL),
(16, 'admin@gmail.com', 'Luap', 'Admin', '22952148596', '$2y$10$kIpbCdvtwnjUw9A2nL9pw.nvKHvwfmm8Vur000uwj5KNIR7ReH.kS', '', '/assets/img/usr_avatar.png', '257856', NULL, NULL, NULL, NULL, 'Just an admin', 'Jobber ponctuel et motivé, il a été disponible ce dimanche matin pour poser ma pelouse synthétique et j’en suis ravie.', NULL, NULL, NULL, NULL, 1, 0, 'chaque', 5, 'enable', '2022-03-04 18:55:35', '2022-03-20 21:52:00', NULL),
(19, 'editeur@gmail.com', 'Dev', 'Editeur', '22951487955', '$2y$10$QvcU/Ku3EnmJqHg6V8/eee.JTyMFBOD.MIcTYb7fnFjwZ7hy5MHGK', '\'\'', '/assets/img/uploads/user/user5504bdcfeadc791a6a399c2b195e1b38.jpg', '257856', NULL, NULL, NULL, NULL, NULL, 'Aucun avis', NULL, NULL, NULL, NULL, 1, 0, 'chaque', 4, 'disable', '2022-03-20 18:45:06', '2022-03-20 21:33:00', NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `addlog_table`
--
ALTER TABLE `addlog_table`
  ADD PRIMARY KEY (`IDEvenement`);

--
-- Index pour la table `adresses`
--
ALTER TABLE `adresses`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `annonces`
--
ALTER TABLE `annonces`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `travail_id` (`travail_id`);

--
-- Index pour la table `badge_identity`
--
ALTER TABLE `badge_identity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `biling_info`
--
ALTER TABLE `biling_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `book_photo`
--
ALTER TABLE `book_photo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categorie_id` (`categorie_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `label` (`label`);

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `from_user_id` (`from_user_id`),
  ADD KEY `to_user_id` (`to_user_id`);

--
-- Index pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `to_user_id` (`to_user_id`);

--
-- Index pour la table `offre_annonce`
--
ALTER TABLE `offre_annonce`
  ADD PRIMARY KEY (`id`),
  ADD KEY `annonce_id` (`annonce_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `paiements`
--
ALTER TABLE `paiements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `offre_id` (`offre_id`),
  ADD KEY `annonce_id` (`annonce_id`),
  ADD KEY `user_client` (`user_client`),
  ADD KEY `user_jobber` (`user_jobber`);

--
-- Index pour la table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `label` (`label`);

--
-- Index pour la table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categorie_id` (`categorie_id`);

--
-- Index pour la table `travaux`
--
ALTER TABLE `travaux`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subcategorie_id` (`subcategorie_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role_id` (`role_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `addlog_table`
--
ALTER TABLE `addlog_table`
  MODIFY `IDEvenement` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT pour la table `adresses`
--
ALTER TABLE `adresses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `annonces`
--
ALTER TABLE `annonces`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT pour la table `badge_identity`
--
ALTER TABLE `badge_identity`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `biling_info`
--
ALTER TABLE `biling_info`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `book_photo`
--
ALTER TABLE `book_photo`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT pour la table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `offre_annonce`
--
ALTER TABLE `offre_annonce`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `paiements`
--
ALTER TABLE `paiements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `travaux`
--
ALTER TABLE `travaux`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `annonces`
--
ALTER TABLE `annonces`
  ADD CONSTRAINT `annonces_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `annonces_ibfk_2` FOREIGN KEY (`travail_id`) REFERENCES `travaux` (`id`);

--
-- Contraintes pour la table `badge_identity`
--
ALTER TABLE `badge_identity`
  ADD CONSTRAINT `badge_identity_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `biling_info`
--
ALTER TABLE `biling_info`
  ADD CONSTRAINT `biling_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `book_photo`
--
ALTER TABLE `book_photo`
  ADD CONSTRAINT `book_photo_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `book_photo_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `offre_annonce`
--
ALTER TABLE `offre_annonce`
  ADD CONSTRAINT `offre_annonce_ibfk_1` FOREIGN KEY (`annonce_id`) REFERENCES `annonces` (`id`),
  ADD CONSTRAINT `offre_annonce_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `paiements`
--
ALTER TABLE `paiements`
  ADD CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`offre_id`) REFERENCES `offre_annonce` (`id`),
  ADD CONSTRAINT `paiements_ibfk_2` FOREIGN KEY (`annonce_id`) REFERENCES `annonces` (`id`),
  ADD CONSTRAINT `paiements_ibfk_3` FOREIGN KEY (`user_client`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `paiements_ibfk_4` FOREIGN KEY (`user_jobber`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `subcategories`
--
ALTER TABLE `subcategories`
  ADD CONSTRAINT `subcategories_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`);

--
-- Contraintes pour la table `travaux`
--
ALTER TABLE `travaux`
  ADD CONSTRAINT `travaux_ibfk_1` FOREIGN KEY (`subcategorie_id`) REFERENCES `subcategories` (`id`);

--
-- Contraintes pour la table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
